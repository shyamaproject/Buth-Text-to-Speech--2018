﻿namespace Buth_Text_to_Speech
{
    partial class Buthtexttospeech
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Buthtexttospeech));
            this.HeaderPicture = new System.Windows.Forms.PictureBox();
            this.pictureBox2 = new System.Windows.Forms.PictureBox();
            this.Namebox = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.Male = new System.Windows.Forms.RadioButton();
            this.Female = new System.Windows.Forms.RadioButton();
            this.Neutral = new System.Windows.Forms.RadioButton();
            this.label4 = new System.Windows.Forms.Label();
            this.Slow = new System.Windows.Forms.RadioButton();
            this.Medium = new System.Windows.Forms.RadioButton();
            this.Fast = new System.Windows.Forms.RadioButton();
            this.label5 = new System.Windows.Forms.Label();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.minimize = new System.Windows.Forms.PictureBox();
            this.crossbutton = new System.Windows.Forms.PictureBox();
            this.selectbox = new System.Windows.Forms.ComboBox();
            this.saveFileDialog1 = new System.Windows.Forms.SaveFileDialog();
            this.label6 = new System.Windows.Forms.Label();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.label9 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.voicespeedreset = new System.Windows.Forms.Button();
            this.voicetypereset = new System.Windows.Forms.Button();
            this.groupBox2 = new System.Windows.Forms.GroupBox();
            this.ratevalue = new System.Windows.Forms.Label();
            this.volumevalue = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.volume = new Baka_MPlayer.Controls.ColorSlider();
            this.voicespeedtraclbar = new Baka_MPlayer.Controls.ColorSlider();
            this.djshyamaname = new AltoControls.AltoSlidingLabel();
            this.Save = new djshyamapbegra.djshyama();
            this.Stop = new djshyamapbegra.djshyama();
            this.Pause = new djshyamapbegra.djshyama();
            this.playbtutton = new djshyamapbegra.djshyama();
            ((System.ComponentModel.ISupportInitialize)(this.HeaderPicture)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.minimize)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.crossbutton)).BeginInit();
            this.groupBox1.SuspendLayout();
            this.groupBox2.SuspendLayout();
            this.SuspendLayout();
            // 
            // HeaderPicture
            // 
            this.HeaderPicture.Dock = System.Windows.Forms.DockStyle.Top;
            this.HeaderPicture.Image = global::Buth_Text_to_Speech.Properties.Resources.sdfsdfsdfsdfsdfsdfsdf;
            this.HeaderPicture.Location = new System.Drawing.Point(0, 0);
            this.HeaderPicture.Name = "HeaderPicture";
            this.HeaderPicture.Size = new System.Drawing.Size(756, 40);
            this.HeaderPicture.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.HeaderPicture.TabIndex = 0;
            this.HeaderPicture.TabStop = false;
            this.HeaderPicture.MouseDown += new System.Windows.Forms.MouseEventHandler(this.HeaderPicture_MouseDown);
            this.HeaderPicture.MouseMove += new System.Windows.Forms.MouseEventHandler(this.HeaderPicture_MouseMove);
            this.HeaderPicture.MouseUp += new System.Windows.Forms.MouseEventHandler(this.HeaderPicture_MouseUp);
            // 
            // pictureBox2
            // 
            this.pictureBox2.BackColor = System.Drawing.Color.Transparent;
            this.pictureBox2.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.pictureBox2.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox2.Image")));
            this.pictureBox2.Location = new System.Drawing.Point(0, 459);
            this.pictureBox2.Name = "pictureBox2";
            this.pictureBox2.Size = new System.Drawing.Size(756, 36);
            this.pictureBox2.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox2.TabIndex = 1;
            this.pictureBox2.TabStop = false;
            this.pictureBox2.MouseDown += new System.Windows.Forms.MouseEventHandler(this.pictureBox2_MouseDown);
            this.pictureBox2.MouseMove += new System.Windows.Forms.MouseEventHandler(this.pictureBox2_MouseMove);
            this.pictureBox2.MouseUp += new System.Windows.Forms.MouseEventHandler(this.pictureBox2_MouseUp);
            // 
            // Namebox
            // 
            this.Namebox.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.Namebox.Location = new System.Drawing.Point(10, 80);
            this.Namebox.Multiline = true;
            this.Namebox.Name = "Namebox";
            this.Namebox.Size = new System.Drawing.Size(410, 272);
            this.Namebox.TabIndex = 2;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.BackColor = System.Drawing.Color.Transparent;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 13F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(437, 50);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(111, 22);
            this.label1.TabIndex = 3;
            this.label1.Text = "Voice Type :";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.BackColor = System.Drawing.Color.Transparent;
            this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 13F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.Location = new System.Drawing.Point(132, 50);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(189, 22);
            this.label2.TabIndex = 4;
            this.label2.Text = "Type Any Word Here :";
            // 
            // Male
            // 
            this.Male.AutoSize = true;
            this.Male.BackColor = System.Drawing.Color.Transparent;
            this.Male.Font = new System.Drawing.Font("Microsoft Sans Serif", 13F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Male.Location = new System.Drawing.Point(441, 80);
            this.Male.Name = "Male";
            this.Male.Size = new System.Drawing.Size(66, 26);
            this.Male.TabIndex = 5;
            this.Male.TabStop = true;
            this.Male.Text = "Male";
            this.Male.UseVisualStyleBackColor = false;
            this.Male.CheckedChanged += new System.EventHandler(this.Male_CheckedChanged);
            // 
            // Female
            // 
            this.Female.AutoSize = true;
            this.Female.BackColor = System.Drawing.Color.Transparent;
            this.Female.Font = new System.Drawing.Font("Microsoft Sans Serif", 13F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Female.Location = new System.Drawing.Point(441, 109);
            this.Female.Name = "Female";
            this.Female.Size = new System.Drawing.Size(87, 26);
            this.Female.TabIndex = 6;
            this.Female.TabStop = true;
            this.Female.Text = "Female";
            this.Female.UseVisualStyleBackColor = false;
            this.Female.CheckedChanged += new System.EventHandler(this.Female_CheckedChanged);
            // 
            // Neutral
            // 
            this.Neutral.AutoSize = true;
            this.Neutral.BackColor = System.Drawing.Color.Transparent;
            this.Neutral.Font = new System.Drawing.Font("Microsoft Sans Serif", 13F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Neutral.Location = new System.Drawing.Point(441, 138);
            this.Neutral.Name = "Neutral";
            this.Neutral.Size = new System.Drawing.Size(86, 26);
            this.Neutral.TabIndex = 7;
            this.Neutral.TabStop = true;
            this.Neutral.Text = "Neutral";
            this.Neutral.UseVisualStyleBackColor = false;
            this.Neutral.CheckedChanged += new System.EventHandler(this.Neutral_CheckedChanged);
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.BackColor = System.Drawing.Color.Transparent;
            this.label4.Font = new System.Drawing.Font("Microsoft Sans Serif", 13F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.Location = new System.Drawing.Point(595, 50);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(127, 22);
            this.label4.TabIndex = 14;
            this.label4.Text = "Voice Speed : ";
            // 
            // Slow
            // 
            this.Slow.AutoSize = true;
            this.Slow.BackColor = System.Drawing.Color.Transparent;
            this.Slow.Font = new System.Drawing.Font("Microsoft Sans Serif", 13F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Slow.Location = new System.Drawing.Point(599, 80);
            this.Slow.Name = "Slow";
            this.Slow.Size = new System.Drawing.Size(67, 26);
            this.Slow.TabIndex = 15;
            this.Slow.TabStop = true;
            this.Slow.Text = "Slow";
            this.Slow.UseVisualStyleBackColor = false;
            this.Slow.CheckedChanged += new System.EventHandler(this.Slow_CheckedChanged);
            // 
            // Medium
            // 
            this.Medium.AutoSize = true;
            this.Medium.BackColor = System.Drawing.Color.Transparent;
            this.Medium.Font = new System.Drawing.Font("Microsoft Sans Serif", 13F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Medium.Location = new System.Drawing.Point(599, 112);
            this.Medium.Name = "Medium";
            this.Medium.Size = new System.Drawing.Size(90, 26);
            this.Medium.TabIndex = 16;
            this.Medium.TabStop = true;
            this.Medium.Text = "Medium";
            this.Medium.UseVisualStyleBackColor = false;
            this.Medium.CheckedChanged += new System.EventHandler(this.Medium_CheckedChanged);
            // 
            // Fast
            // 
            this.Fast.AutoSize = true;
            this.Fast.BackColor = System.Drawing.Color.Transparent;
            this.Fast.Font = new System.Drawing.Font("Microsoft Sans Serif", 13F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Fast.Location = new System.Drawing.Point(599, 144);
            this.Fast.Name = "Fast";
            this.Fast.Size = new System.Drawing.Size(63, 26);
            this.Fast.TabIndex = 17;
            this.Fast.TabStop = true;
            this.Fast.Text = "Fast";
            this.Fast.UseVisualStyleBackColor = false;
            this.Fast.CheckedChanged += new System.EventHandler(this.Fast_CheckedChanged);
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.BackColor = System.Drawing.Color.Transparent;
            this.label5.Font = new System.Drawing.Font("Microsoft Sans Serif", 13F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label5.Location = new System.Drawing.Point(113, 83);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(80, 22);
            this.label5.TabIndex = 18;
            this.label5.Text = "Volume :";
            // 
            // pictureBox1
            // 
            this.pictureBox1.BackColor = System.Drawing.Color.Transparent;
            this.pictureBox1.BackgroundImage = global::Buth_Text_to_Speech.Properties.Resources.sdfsdfsdfsdfsdfsdfsdf;
            this.pictureBox1.Image = global::Buth_Text_to_Speech.Properties.Resources.buth;
            this.pictureBox1.Location = new System.Drawing.Point(264, 3);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(218, 34);
            this.pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox1.TabIndex = 27;
            this.pictureBox1.TabStop = false;
            this.pictureBox1.MouseDown += new System.Windows.Forms.MouseEventHandler(this.pictureBox1_MouseDown);
            this.pictureBox1.MouseMove += new System.Windows.Forms.MouseEventHandler(this.pictureBox1_MouseMove);
            this.pictureBox1.MouseUp += new System.Windows.Forms.MouseEventHandler(this.pictureBox1_MouseUp);
            // 
            // minimize
            // 
            this.minimize.BackColor = System.Drawing.Color.Transparent;
            this.minimize.BackgroundImage = global::Buth_Text_to_Speech.Properties.Resources.sdfsdfsdfsdfsdfsdfsdf;
            this.minimize.Image = global::Buth_Text_to_Speech.Properties.Resources.djshyamaminus;
            this.minimize.Location = new System.Drawing.Point(681, 3);
            this.minimize.Name = "minimize";
            this.minimize.Size = new System.Drawing.Size(34, 34);
            this.minimize.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.minimize.TabIndex = 28;
            this.minimize.TabStop = false;
            this.minimize.Click += new System.EventHandler(this.minimize_Click);
            this.minimize.Paint += new System.Windows.Forms.PaintEventHandler(this.minimize_Paint);
            // 
            // crossbutton
            // 
            this.crossbutton.BackColor = System.Drawing.Color.Transparent;
            this.crossbutton.BackgroundImage = global::Buth_Text_to_Speech.Properties.Resources.sdfsdfsdfsdfsdfsdfsdf;
            this.crossbutton.Image = global::Buth_Text_to_Speech.Properties.Resources.djshyamaclose;
            this.crossbutton.Location = new System.Drawing.Point(715, 3);
            this.crossbutton.Name = "crossbutton";
            this.crossbutton.Size = new System.Drawing.Size(34, 34);
            this.crossbutton.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.crossbutton.TabIndex = 29;
            this.crossbutton.TabStop = false;
            this.crossbutton.Click += new System.EventHandler(this.crossbutton_Click);
            this.crossbutton.Paint += new System.Windows.Forms.PaintEventHandler(this.crossbutton_Paint);
            // 
            // selectbox
            // 
            this.selectbox.Font = new System.Drawing.Font("Microsoft Sans Serif", 11F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.selectbox.FormattingEnabled = true;
            this.selectbox.Location = new System.Drawing.Point(6, 50);
            this.selectbox.Name = "selectbox";
            this.selectbox.Size = new System.Drawing.Size(396, 26);
            this.selectbox.TabIndex = 30;
            this.selectbox.Tag = "0";
            this.selectbox.SelectedIndexChanged += new System.EventHandler(this.selectbox_SelectedIndexChanged);
            // 
            // saveFileDialog1
            // 
            this.saveFileDialog1.Filter = "*.wav|*.wav|*.mp3|*.mp3";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.BackColor = System.Drawing.Color.Transparent;
            this.label6.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label6.Location = new System.Drawing.Point(140, 20);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(117, 20);
            this.label6.TabIndex = 32;
            this.label6.Text = "Voice Setting";
            // 
            // groupBox1
            // 
            this.groupBox1.BackColor = System.Drawing.Color.Transparent;
            this.groupBox1.Controls.Add(this.label6);
            this.groupBox1.Controls.Add(this.selectbox);
            this.groupBox1.Location = new System.Drawing.Point(12, 358);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(408, 95);
            this.groupBox1.TabIndex = 33;
            this.groupBox1.TabStop = false;
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.BackColor = System.Drawing.Color.Transparent;
            this.label9.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label9.Image = ((System.Drawing.Image)(resources.GetObject("label9.Image")));
            this.label9.Location = new System.Drawing.Point(180, 469);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(0, 17);
            this.label9.TabIndex = 36;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.BackColor = System.Drawing.Color.Transparent;
            this.label3.Font = new System.Drawing.Font("Microsoft Sans Serif", 13F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.Location = new System.Drawing.Point(118, 10);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(58, 22);
            this.label3.TabIndex = 37;
            this.label3.Text = "Rate :";
            // 
            // voicespeedreset
            // 
            this.voicespeedreset.BackColor = System.Drawing.Color.Transparent;
            this.voicespeedreset.BackgroundImage = global::Buth_Text_to_Speech.Properties.Resources.sdfsdfsdfsdfsdfsdfsdf;
            this.voicespeedreset.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.voicespeedreset.Font = new System.Drawing.Font("Microsoft Sans Serif", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.voicespeedreset.Location = new System.Drawing.Point(621, 176);
            this.voicespeedreset.Name = "voicespeedreset";
            this.voicespeedreset.Size = new System.Drawing.Size(63, 28);
            this.voicespeedreset.TabIndex = 38;
            this.voicespeedreset.Text = "Reset";
            this.voicespeedreset.UseVisualStyleBackColor = false;
            this.voicespeedreset.Click += new System.EventHandler(this.voicespeedreset_Click);
            // 
            // voicetypereset
            // 
            this.voicetypereset.BackColor = System.Drawing.Color.Transparent;
            this.voicetypereset.BackgroundImage = global::Buth_Text_to_Speech.Properties.Resources.sdfsdfsdfsdfsdfsdfsdf;
            this.voicetypereset.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.voicetypereset.Font = new System.Drawing.Font("Microsoft Sans Serif", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.voicetypereset.Location = new System.Drawing.Point(463, 176);
            this.voicetypereset.Name = "voicetypereset";
            this.voicetypereset.Size = new System.Drawing.Size(63, 28);
            this.voicetypereset.TabIndex = 39;
            this.voicetypereset.Text = "Reset";
            this.voicetypereset.UseVisualStyleBackColor = false;
            this.voicetypereset.Click += new System.EventHandler(this.voicetypereset_Click);
            // 
            // groupBox2
            // 
            this.groupBox2.BackColor = System.Drawing.Color.Transparent;
            this.groupBox2.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None;
            this.groupBox2.Controls.Add(this.ratevalue);
            this.groupBox2.Controls.Add(this.volumevalue);
            this.groupBox2.Controls.Add(this.volume);
            this.groupBox2.Controls.Add(this.label5);
            this.groupBox2.Controls.Add(this.voicespeedtraclbar);
            this.groupBox2.Controls.Add(this.label3);
            this.groupBox2.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.groupBox2.Location = new System.Drawing.Point(442, 222);
            this.groupBox2.Name = "groupBox2";
            this.groupBox2.Size = new System.Drawing.Size(297, 162);
            this.groupBox2.TabIndex = 40;
            this.groupBox2.TabStop = false;
            // 
            // ratevalue
            // 
            this.ratevalue.AutoSize = true;
            this.ratevalue.BackColor = System.Drawing.Color.Transparent;
            this.ratevalue.Font = new System.Drawing.Font("Microsoft Sans Serif", 13F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.ratevalue.Location = new System.Drawing.Point(138, 60);
            this.ratevalue.Name = "ratevalue";
            this.ratevalue.Size = new System.Drawing.Size(20, 22);
            this.ratevalue.TabIndex = 39;
            this.ratevalue.Text = "0";
            // 
            // volumevalue
            // 
            this.volumevalue.AutoSize = true;
            this.volumevalue.BackColor = System.Drawing.Color.Transparent;
            this.volumevalue.Font = new System.Drawing.Font("Microsoft Sans Serif", 13F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.volumevalue.Location = new System.Drawing.Point(138, 135);
            this.volumevalue.Name = "volumevalue";
            this.volumevalue.Size = new System.Drawing.Size(20, 22);
            this.volumevalue.TabIndex = 38;
            this.volumevalue.Text = "0";
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.BackColor = System.Drawing.Color.Transparent;
            this.label7.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label7.Image = global::Buth_Text_to_Speech.Properties.Resources.sdfsdfsdfsdfsdfsdfsdf;
            this.label7.Location = new System.Drawing.Point(467, 10);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(34, 20);
            this.label7.TabIndex = 42;
            this.label7.Text = "1.0";
            // 
            // volume
            // 
            this.volume.BackColor = System.Drawing.Color.Transparent;
            this.volume.BarColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(192)))), ((int)(((byte)(0)))));
            this.volume.BorderRoundRectSize = new System.Drawing.Size(8, 8);
            this.volume.ElapsedBarColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(192)))), ((int)(((byte)(0)))));
            this.volume.LargeChange = ((uint)(5u));
            this.volume.Location = new System.Drawing.Point(16, 108);
            this.volume.Minimum = -100;
            this.volume.Name = "volume";
            this.volume.Size = new System.Drawing.Size(264, 23);
            this.volume.SmallChange = ((uint)(1u));
            this.volume.TabIndex = 20;
            this.volume.Text = "volume";
            this.volume.ThumbBorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(192)))), ((int)(((byte)(0)))));
            this.volume.ThumbRoundRectSize = new System.Drawing.Size(8, 8);
            this.volume.ThumbSecondColor = System.Drawing.Color.Lime;
            this.volume.Value = 0;
            this.volume.Scroll += new System.Windows.Forms.ScrollEventHandler(this.volume_Scroll);
            // 
            // voicespeedtraclbar
            // 
            this.voicespeedtraclbar.BackColor = System.Drawing.Color.Transparent;
            this.voicespeedtraclbar.BarColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(192)))), ((int)(((byte)(0)))));
            this.voicespeedtraclbar.BorderRoundRectSize = new System.Drawing.Size(8, 8);
            this.voicespeedtraclbar.ElapsedBarColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(192)))), ((int)(((byte)(0)))));
            this.voicespeedtraclbar.LargeChange = ((uint)(5u));
            this.voicespeedtraclbar.Location = new System.Drawing.Point(16, 36);
            this.voicespeedtraclbar.Maximum = 10;
            this.voicespeedtraclbar.Minimum = -10;
            this.voicespeedtraclbar.Name = "voicespeedtraclbar";
            this.voicespeedtraclbar.Size = new System.Drawing.Size(264, 23);
            this.voicespeedtraclbar.SmallChange = ((uint)(1u));
            this.voicespeedtraclbar.TabIndex = 19;
            this.voicespeedtraclbar.Text = "voicespeedtraclbar";
            this.voicespeedtraclbar.ThumbBorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(192)))), ((int)(((byte)(0)))));
            this.voicespeedtraclbar.ThumbRoundRectSize = new System.Drawing.Size(8, 8);
            this.voicespeedtraclbar.ThumbSecondColor = System.Drawing.Color.Lime;
            this.voicespeedtraclbar.Value = 0;
            this.voicespeedtraclbar.Scroll += new System.Windows.Forms.ScrollEventHandler(this.voicespeedtraclbar_Scroll);
            // 
            // djshyamaname
            // 
            this.djshyamaname.BackColor = System.Drawing.Color.Transparent;
            this.djshyamaname.BackgroundImage = global::Buth_Text_to_Speech.Properties.Resources.sdfsdfsdfsdfsdfsdfsdf;
            this.djshyamaname.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.djshyamaname.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.djshyamaname.Location = new System.Drawing.Point(3, 459);
            this.djshyamaname.Name = "djshyamaname";
            this.djshyamaname.Size = new System.Drawing.Size(73, 34);
            this.djshyamaname.Slide = false;
            this.djshyamaname.TabIndex = 26;
            this.djshyamaname.Text = "djshyama";
            // 
            // Save
            // 
            this.Save.BackColor = System.Drawing.Color.Transparent;
            this.Save.ButtonColorBottom = System.Drawing.Color.Lime;
            this.Save.ButtonColorTop = System.Drawing.Color.Yellow;
            this.Save.FocusColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(192)))), ((int)(((byte)(0)))));
            this.Save.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Save.ForeColor = System.Drawing.SystemColors.ControlText;
            this.Save.Location = new System.Drawing.Point(672, 390);
            this.Save.Name = "Save";
            this.Save.PulseColor = System.Drawing.Color.Chartreuse;
            this.Save.PulseSpeed = 0.1F;
            this.Save.Size = new System.Drawing.Size(67, 63);
            this.Save.TabIndex = 25;
            this.Save.Text = "Save";
            this.Save.UseVisualStyleBackColor = false;
            this.Save.Click += new System.EventHandler(this.Save_Click);
            // 
            // Stop
            // 
            this.Stop.BackColor = System.Drawing.Color.Transparent;
            this.Stop.ButtonColorBottom = System.Drawing.Color.Lime;
            this.Stop.ButtonColorTop = System.Drawing.Color.Yellow;
            this.Stop.FocusColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(192)))), ((int)(((byte)(0)))));
            this.Stop.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Stop.ForeColor = System.Drawing.SystemColors.ControlText;
            this.Stop.Location = new System.Drawing.Point(599, 390);
            this.Stop.Name = "Stop";
            this.Stop.PulseColor = System.Drawing.Color.Chartreuse;
            this.Stop.PulseSpeed = 0.1F;
            this.Stop.Size = new System.Drawing.Size(67, 63);
            this.Stop.TabIndex = 23;
            this.Stop.Text = "Stop";
            this.Stop.UseVisualStyleBackColor = false;
            this.Stop.Click += new System.EventHandler(this.Stop_Click);
            // 
            // Pause
            // 
            this.Pause.BackColor = System.Drawing.Color.Transparent;
            this.Pause.ButtonColorBottom = System.Drawing.Color.Lime;
            this.Pause.ButtonColorTop = System.Drawing.Color.Yellow;
            this.Pause.FocusColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(192)))), ((int)(((byte)(0)))));
            this.Pause.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Pause.ForeColor = System.Drawing.SystemColors.ControlText;
            this.Pause.Location = new System.Drawing.Point(526, 390);
            this.Pause.Name = "Pause";
            this.Pause.PulseColor = System.Drawing.Color.Chartreuse;
            this.Pause.PulseSpeed = 0.1F;
            this.Pause.Size = new System.Drawing.Size(67, 63);
            this.Pause.TabIndex = 22;
            this.Pause.Text = "Pause";
            this.Pause.UseVisualStyleBackColor = false;
            this.Pause.Click += new System.EventHandler(this.Pause_Click);
            // 
            // playbtutton
            // 
            this.playbtutton.BackColor = System.Drawing.Color.Transparent;
            this.playbtutton.ButtonColorBottom = System.Drawing.Color.Lime;
            this.playbtutton.ButtonColorTop = System.Drawing.Color.Yellow;
            this.playbtutton.FocusColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(192)))), ((int)(((byte)(0)))));
            this.playbtutton.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.playbtutton.ForeColor = System.Drawing.SystemColors.ControlText;
            this.playbtutton.Location = new System.Drawing.Point(453, 390);
            this.playbtutton.Name = "playbtutton";
            this.playbtutton.PulseColor = System.Drawing.Color.Chartreuse;
            this.playbtutton.PulseSpeed = 0.1F;
            this.playbtutton.Size = new System.Drawing.Size(67, 63);
            this.playbtutton.TabIndex = 21;
            this.playbtutton.Text = "Play";
            this.playbtutton.UseVisualStyleBackColor = false;
            this.playbtutton.Click += new System.EventHandler(this.playbtutton_Click);
            // 
            // Buthtexttospeech
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackgroundImage = global::Buth_Text_to_Speech.Properties.Resources.djshyamadesktophr;
            this.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.ClientSize = new System.Drawing.Size(756, 495);
            this.Controls.Add(this.label7);
            this.Controls.Add(this.groupBox2);
            this.Controls.Add(this.voicetypereset);
            this.Controls.Add(this.voicespeedreset);
            this.Controls.Add(this.label9);
            this.Controls.Add(this.groupBox1);
            this.Controls.Add(this.crossbutton);
            this.Controls.Add(this.minimize);
            this.Controls.Add(this.pictureBox1);
            this.Controls.Add(this.djshyamaname);
            this.Controls.Add(this.Save);
            this.Controls.Add(this.Stop);
            this.Controls.Add(this.Pause);
            this.Controls.Add(this.playbtutton);
            this.Controls.Add(this.Fast);
            this.Controls.Add(this.Medium);
            this.Controls.Add(this.Slow);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.Neutral);
            this.Controls.Add(this.Female);
            this.Controls.Add(this.Male);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.Namebox);
            this.Controls.Add(this.pictureBox2);
            this.Controls.Add(this.HeaderPicture);
            this.DoubleBuffered = true;
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Name = "Buthtexttospeech";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Buthtexttospeech";
            this.Load += new System.EventHandler(this.Buthtexttospeech_Load);
            this.MouseDown += new System.Windows.Forms.MouseEventHandler(this.Buthtexttospeech_MouseDown);
            this.MouseMove += new System.Windows.Forms.MouseEventHandler(this.Buthtexttospeech_MouseMove);
            this.MouseUp += new System.Windows.Forms.MouseEventHandler(this.Buthtexttospeech_MouseUp);
            ((System.ComponentModel.ISupportInitialize)(this.HeaderPicture)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.minimize)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.crossbutton)).EndInit();
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            this.groupBox2.ResumeLayout(false);
            this.groupBox2.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.PictureBox HeaderPicture;
        private System.Windows.Forms.PictureBox pictureBox2;
        private System.Windows.Forms.TextBox Namebox;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.RadioButton Male;
        private System.Windows.Forms.RadioButton Female;
        private System.Windows.Forms.RadioButton Neutral;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.RadioButton Slow;
        private System.Windows.Forms.RadioButton Medium;
        private System.Windows.Forms.RadioButton Fast;
        private System.Windows.Forms.Label label5;
        private Baka_MPlayer.Controls.ColorSlider voicespeedtraclbar;
        private Baka_MPlayer.Controls.ColorSlider volume;
        private djshyamapbegra.djshyama playbtutton;
        private djshyamapbegra.djshyama Pause;
        private djshyamapbegra.djshyama Stop;
        private djshyamapbegra.djshyama Save;
        private AltoControls.AltoSlidingLabel djshyamaname;
        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.PictureBox minimize;
        private System.Windows.Forms.PictureBox crossbutton;
        private System.Windows.Forms.ComboBox selectbox;
        private System.Windows.Forms.SaveFileDialog saveFileDialog1;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Button voicespeedreset;
        private System.Windows.Forms.Button voicetypereset;
        private System.Windows.Forms.GroupBox groupBox2;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label volumevalue;
        private System.Windows.Forms.Label ratevalue;
    }
}

