﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.Speech;
using System.Speech.Synthesis;
using System.Globalization;

namespace Buth_Text_to_Speech
{
    public partial class Buthtexttospeech : Form
    {
        private SpeechSynthesizer reader;
      
        public Buthtexttospeech()
        {
            InitializeComponent();

            reader = new SpeechSynthesizer();
            Panel pnlTop = new Panel() { Height = 2, Dock = DockStyle.Top, BackColor = Color.Green };
            this.Controls.Add(pnlTop);
            Panel pnlRight = new Panel() { Width = 2, Dock = DockStyle.Right, BackColor = Color.Green };
            this.Controls.Add(pnlRight);
            Panel pnlBottom = new Panel() { Height = 2, Dock = DockStyle.Bottom, BackColor = Color.Green };
            this.Controls.Add(pnlBottom);
            Panel pnlLeft = new Panel() { Width = 2, Dock = DockStyle.Left, BackColor = Color.Green };
            this.Controls.Add(pnlLeft);

        }

        private void PopulateInstalledVoices()
        {
            if (reader != null)
                foreach (InstalledVoice voice in reader.GetInstalledVoices())
                {
                    VoiceInfo info = voice.VoiceInfo;
                    selectbox.Items.Add(info.Name);
                }
            selectbox.SelectedIndex = 0;
        }


        private void Buthtexttospeech_Load(object sender, EventArgs e)
        {
            PopulateInstalledVoices();
        }



        #region Headerclass
        private void minimize_Paint(object sender, PaintEventArgs e) { }
        private void crossbutton_Paint(object sender, PaintEventArgs e) { }
        #endregion

        #region Play,pause,stop
        private void playbtutton_Click(object sender, EventArgs e)
        {
            try
            {
                if (string.IsNullOrEmpty(Namebox.Text))
                {
                    MessageBox.Show("Please Enter Something in the TextBox ", "djshyama Message", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
                else
                {
                    reader = new SpeechSynthesizer();
                    reader.Rate = voicespeedtraclbar.Value;
                    reader.Volume = volume.Value;
                    reader.SelectVoice(selectbox.Text);
                    reader.SpeakAsync(Namebox.Text.Trim());


                }
            }
            catch { }
           
        }

        private void Pause_Click(object sender, EventArgs e)
        {
            try
            {
                if (Namebox.Text != null)

                    if (reader.State == SynthesizerState.Speaking)
                    {
                        reader.Pause();
                    }
                    else
                    {
                        if (string.IsNullOrEmpty(Namebox.Text))
                        {
                            MessageBox.Show("Please Enter Something in the TextBox ", "djshyama Message", MessageBoxButtons.OK, MessageBoxIcon.Error);
                        }
                    }
            }
            catch { }
           
        }

        private void Stop_Click(object sender, EventArgs e)
        {
            try
            {
                if (string.IsNullOrEmpty(Namebox.Text))
                {
                    MessageBox.Show("Please Enter Something in the TextBox ", "djshyama Message", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }

                if (reader != null && Namebox.Text != null)
                {
                    reader.Dispose();
                }
            }
            catch { }
           
           
        }
        #endregion

        #region Save File
        private void Save_Click(object sender, EventArgs e)
        {
            if (string.IsNullOrEmpty(Namebox.Text))
            {
                MessageBox.Show("Textbox is empty, please add text", "djshyama message", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            else
            {
                var _in = saveFileDialog1.ShowDialog();
                if (_in == DialogResult.OK)
                {
                    if (reader != null)
                    {
                        reader.Dispose();
                    }

                    reader = new SpeechSynthesizer();
                    reader.Rate = voicespeedtraclbar.Value;
                    reader.Volume = volume.Value;
                    reader.SelectVoice(selectbox.Text);
                    reader.SetOutputToWaveFile(saveFileDialog1.FileName);
                    reader.SpeakAsync(Namebox.Text.Trim());
                    reader.SpeakCompleted += new EventHandler<SpeakCompletedEventArgs>(reader_SaveCompleted);

                }
            }
        }

        void reader_SaveCompleted(object sender, SpeakCompletedEventArgs e)
        {
            reader.SetOutputToNull();
            MessageBox.Show("File is Saved", " Save File", MessageBoxButtons.OK, MessageBoxIcon.Information);
        }
        #endregion

        #region volume,rate
        private void Slow_CheckedChanged(object sender, EventArgs e)
        {
            if (Slow.Checked == true)
            {
                voicespeedtraclbar.Value = -8;
            }
        }

        private void Medium_CheckedChanged(object sender, EventArgs e)
        {
            if (Medium.Checked == true)
            {
                voicespeedtraclbar.Value = 0;
            }
            
        }

        private void Fast_CheckedChanged(object sender, EventArgs e)
        {
            if (Fast.Checked == true)
            {
                voicespeedtraclbar.Value = 8;
            }
        }
        #endregion

        #region male,female
        private void Male_CheckedChanged(object sender, EventArgs e)
        {
            try
            {
                if (Namebox.Text != null)

                    if (Male.Checked == true)
                    {
                        reader.SelectVoiceByHints(VoiceGender.Male);
                        reader.SpeakAsync(Namebox.Text);
                        selectbox.Enabled = false;

                    }
                    else
                    {
                        selectbox.Enabled = true;
                    }

            }
            catch { }
        }
        private void Female_CheckedChanged(object sender, EventArgs e)
        {
            try
            {
                if (Namebox.Text != null)

                    if (Female.Checked == true)
                    {
                        reader.SelectVoiceByHints(VoiceGender.Female);
                        reader.SpeakAsync(Namebox.Text);
                        selectbox.Enabled = false;

                    }
                    else
                    {
                        selectbox.Enabled = true;
                    }

            }
            catch { }

        }

        private void Neutral_CheckedChanged(object sender, EventArgs e)
        {
            try
            {
                if (Namebox.Text != null)

                    if (Neutral.Checked == true)
                    {
                        reader.SelectVoiceByHints(VoiceGender.Neutral);
                        reader.SpeakAsync(Namebox.Text);
                        selectbox.Enabled = false;

                    }
                    else
                    {
                        selectbox.Enabled = true;
                    }

            }
            catch { }
        
        }

        #endregion

        #region voicespeed,voicetype
        private void selectbox_SelectedIndexChanged(object sender, EventArgs e){}

        private void voicetypereset_Click(object sender, EventArgs e)
        {
            Male.Checked = false;
            Female.Checked = false;
            Neutral.Checked = false;
        }

        private void voicespeedreset_Click(object sender, EventArgs e)
        {
            Slow.Checked = false;
            Medium.Checked = false;
            Fast.Checked = false;

        }
        #endregion

        private void volume_Scroll(object sender, ScrollEventArgs e)
        {
            volumevalue.Text = volume.Value.ToString();
            
        }
        private void voicespeedtraclbar_Scroll(object sender, ScrollEventArgs e)
        {
            ratevalue.Text = voicespeedtraclbar.Value.ToString();
        }


    }

}